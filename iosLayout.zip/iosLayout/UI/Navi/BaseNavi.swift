//
//  BaseNavi.swift
//  iosLayout
//
//  Created by nguyen thi ngoc hau on 2022/01/27.
//

import UIKit

class BaseNavi: UINavigationController {
//    private var underLineView: UIView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        //背景色
        self.navigationBar.barTintColor = UIColor(named: "angeBrown")
        //透過なし、viewの(0, 0)はnavigationの下になる
        self.navigationBar.isTranslucent = false
    }
}
