//
//  BaseNavi.swift
//  iosLayout
//
//  Created by nguyen thi ngoc hau on 2022/01/27.
//

import UIKit

class BaseNavi: UINavigationController {
    override func viewDidLoad() {
        super.viewDidLoad()
        //背景色
        self.navigationBar.barTintColor = UIColor(named: "angeBrown")
        //透過なし、viewの(0, 0)はnavigationの下になる
        self.navigationBar.isTranslucent = false
        
        if #available(iOS 15.0, *) {
            let appearanceNav = UINavigationBarAppearance()
            appearanceNav.configureWithOpaqueBackground()
            appearanceNav.backgroundColor = .cyan
            appearanceNav.titleTextAttributes = [NSAttributedString.Key.font : UIFont.boldSystemFont(ofSize: 15), NSAttributedString.Key.foregroundColor: UIColor.white]
            navigationController?.navigationBar.standardAppearance = appearanceNav
            navigationController?.navigationBar.scrollEdgeAppearance = appearanceNav
        } else {
            navigationController?.navigationBar.barTintColor = .cyan
            navigationController?.navigationBar.titleTextAttributes = [NSAttributedString.Key.font : UIFont.boldSystemFont(ofSize: 15), NSAttributedString.Key.foregroundColor: UIColor.white]
        }
    }
}
