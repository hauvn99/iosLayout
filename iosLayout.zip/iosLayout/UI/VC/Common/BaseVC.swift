//
//  BaseVC.swift
//  iosLayout
//
//  Created by nguyen thi ngoc hau on 2022/01/27.
//

import UIKit

class BaseVC: UIViewController {
    override func viewDidLoad() {
        super.viewDidLoad()
        if #available(iOS 15.0, *) {
            let appearance = UINavigationBarAppearance()
            appearance.configureWithOpaqueBackground()
            appearance.titleTextAttributes = [NSAttributedString.Key.font : UIFont.boldSystemFont(ofSize: 15), NSAttributedString.Key.foregroundColor : UIColor.white]
            appearance.backgroundColor = .brown
            navigationController?.navigationBar.standardAppearance = appearance
            navigationController?.navigationBar.scrollEdgeAppearance = appearance
        } else {
            self.navigationController?.navigationBar.tintColor = UIColor.clear
        }
        view.backgroundColor = .white
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
    }

    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
    }
    
    func setBrownNav() {
        self.navigationController?.navigationBar.barTintColor = UIColor.brown
        let font = UIFont.boldSystemFont(ofSize: 15)
        self.navigationController?.navigationBar.titleTextAttributes = [NSAttributedString.Key.font : font, NSAttributedString.Key.foregroundColor : UIColor.white]
    }
    
    func setWhiteBackButton(){
//        let barButtonItem = UIBarButtonItem(image: UIImage(named: "header_btn_back_white")!.withRenderingMode(.alwaysOriginal) , style: .plain, target: self, action: #selector(BaseVC.pushedBackButton))
//        self.navigationItem.leftBarButtonItems?.removeAll()
//        self.navigationItem.addLeftBarButtonItem(item: barButtonItem, isLastPosition: false)
    }
    
    // ナビゲーションをブラウンなどに設定した後に元にする
    func resetNavStyle() {
        self.navigationController?.navigationBar.barStyle = UIBarStyle.default
        self.navigationController?.navigationBar.barTintColor = UIColor.white
        let font = UIFont.boldSystemFont(ofSize: 15)
        self.navigationController?.navigationBar.titleTextAttributes = [NSAttributedString.Key.font : font, NSAttributedString.Key.foregroundColor : UIColor.gray]
        self.navigationItem.leftBarButtonItems?.removeAll()
    }
}
