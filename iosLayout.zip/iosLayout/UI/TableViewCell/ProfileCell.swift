//
//  ProfileCell.swift
//  iosLayout
//
//  Created by nguyen thi ngoc hau on 2022/01/26.
//

import UIKit

class ProfileCell: UITableViewCell {
    @IBOutlet weak var imgView: UIImageView!
    @IBOutlet weak var onlineView: UIView!
    @IBOutlet weak var onlineMark: UIImageView!
    @IBOutlet weak var agePrefLabel: UILabel!
    @IBOutlet weak var subPhotoNumView: UIView!
    @IBOutlet weak var subPhotoNumLabel: UILabel!
    @IBOutlet weak var prLabel: UILabel!
    @IBOutlet weak var iconNew: UIImageView!
    private var data: SearchMember!
    
    override func awakeFromNib() {
        super.awakeFromNib()
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        print(data.nickname!)
    }
    
    func config(data: SearchMember) {
        self.data = data
        self.renderView()
    }
    
    func renderView() {
        self.imgView.image = UIImage(named: self.data.profilePhotoUrl!)
        let prText:String! = self.data.pr != nil ? self.data.pr?.replacingOccurrences(of: "\r\n|\n", with: "", options: NSString.CompareOptions.regularExpression, range: nil) : "はじめまして！"
        
        var attributes: [NSAttributedString.Key: Any] = [:]
        let paragraphStyle = NSMutableParagraphStyle()
        paragraphStyle.lineSpacing = 3.0
        paragraphStyle.alignment = .left
        paragraphStyle.lineBreakMode = .byTruncatingTail
        attributes.updateValue(paragraphStyle, forKey: .paragraphStyle)
        self.prLabel.attributedText = NSAttributedString(string: prText + "\n", attributes: attributes)
        self.prLabel.numberOfLines = 2
        self.prLabel.lineBreakMode = .byTruncatingTail
        self.agePrefLabel.text = "\(ls("profile_age1", args: self.data.age!)) \(self.data.prefName!)"
        
        var photoCnt: Int = self.data.subphotoCnt
        photoCnt = photoCnt > 99 ? 99 : photoCnt
        if photoCnt > 0 {
            self.subPhotoNumView.isHidden = false
            self.subPhotoNumLabel.text = String(photoCnt)
        } else {
            self.subPhotoNumView.isHidden = true
        }
        if self.data.isNew == 1 {
            self.iconNew.isHidden = false
        } else {
            self.iconNew.isHidden = true
        }
        
        switch(self.data.loginStatus!) {
        case 1:
            self.onlineView.isHidden = false
            self.onlineMark.image = UIImage(named: "icon_online")
            break
        case 0:
            self.onlineView.isHidden = false
            self.onlineMark.image = UIImage(named: "icon_online24")
            break
        default:
            self.onlineView.isHidden = true
            break
        }
    }
}
