//
//  VocabVC.swift
//  iosLayout
//
//  Created by nguyen thi ngoc hau on 2022/01/31.
//

import UIKit

class VocabVC: UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.renderView()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
    }
    
    func renderView() {
        print("VocabVC")
    }
}
