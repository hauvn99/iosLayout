//
//  ReadVC.swift
//  iosLayout
//
//  Created by nguyen thi ngoc hau on 2022/01/31.
//

import UIKit

class ReadVC: BaseVC {
    override var preferredStatusBarStyle: UIStatusBarStyle {
        return .lightContent
    }
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.renderView()
    }
    
    func renderView() {
        title = "読解"
        print("ReadVC")
    }
}
