//
//  KanjiVC.swift
//  iosLayout
//
//  Created by nguyen thi ngoc hau on 2022/01/31.
//

import UIKit

class KanjiVC: UIViewController {
    var level: String!
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.renderView()
    }
    
    func renderView() {
        title = "漢字"
        self.renderData()
    }
    
    @IBAction func didTapButton() {
        let vc = UIViewController()
        vc.view.backgroundColor = .white
        navigationController?.pushViewController(vc, animated: false)
    }
    
    func renderData() {
        do {
            let fileURL = Bundle.main.url(forResource: "test", withExtension: "json")!
            let responseData = try Data(contentsOf: fileURL)
            //print(responseData)
            do {
                let decoder: JSONDecoder = JSONDecoder()
                let json = try decoder.decode(KanjiStructue.self, from: responseData)
                print("+++++++++++++++++++++++++")
                print(json)
                json.data.forEach {
                    print($0.kanji)
                }
            } catch {
                return
            }
        } catch {
            print(error)
        }
    }
}
