//
//  JapaneseTBC.swift
//  iosLayout
//
//  Created by nguyen thi ngoc hau on 2022/02/02.
//

import UIKit
//Create Tab Bar App with Navigation in Swift 5 (Xcode 11) - 2022 iOS
//https://www.youtube.com/watch?v=Nx3qPQ_qOFM
//Swift: Create Tab Bar Controller Programmatically (Swift 5, Xcode 11) - 2020 iOS
//https://www.youtube.com/watch?v=6CEWHlM8Ecw

class JapaneseTBC: UITabBarController, UITabBarControllerDelegate {
    private static var current: JapaneseTBC!
    static func changeRootVC() {
//        JapaneseTBC.current = ViewUtil.loadStoryboardInitialVC(storyboard: "JapaneseTBC")
//        ViewUtil.changeRootVC(vc: JapaneseTBC.current)
    }
    
    override func viewDidLoad(){
        super.viewDidLoad()
        view.backgroundColor = .systemBlue
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        print("JapaneseTBC")
    }
}
