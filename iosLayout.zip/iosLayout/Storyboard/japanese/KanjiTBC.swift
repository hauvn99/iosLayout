//
//  KanjiTBC.swift
//  iosLayout
//
//  Created by nguyen thi ngoc hau on 2022/01/31.
//

import UIKit
enum Level: String {
    case n5 = "N5"
    case n4 = "N4"
    case n3 = "N3"
    case n2 = "N2"
    case n1 = "N1"
}

class KanjiTBC: UITabBarController, UITabBarControllerDelegate {
    
    override var selectedIndex: Int {
        get { return super.selectedIndex }
        set {
            super.selectedIndex = newValue
        }
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.renderView()
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
//        if #available(iOS 15.0, *) {
//            let appearance = UITabBarAppearance()
//            appearance.configureWithOpaqueBackground()
//            appearance.backgroundColor = .green
//            tabBar.standardAppearance = appearance
//            tabBar.scrollEdgeAppearance = tabBar.standardAppearance
//        }
//        self.tabBarController?.tabBar.borderColor = .red
//        self.tabBarController?.tabBar.shadowImage = UIImage()
//        self.tabBarController?.tabBar.backgroundImage = UIImage()
//        self.tabBar.barTintColor = .red
//        self.tabBar.items![0].image = UIImage(named: "icon_nav_main_off")!.withRenderingMode(UIImage.RenderingMode.alwaysOriginal)
//        self.tabBar.items![1].image = UIImage(named: "icon_nav_keep_off")!.withRenderingMode(UIImage.RenderingMode.alwaysOriginal)
//        self.tabBar.items![2].image = UIImage(named: "icon_nav_footprint_off")!.withRenderingMode(UIImage.RenderingMode.alwaysOriginal)
//        self.tabBar.items![3].image = UIImage(named: "icon_nav_message_off")!.withRenderingMode(UIImage.RenderingMode.alwaysOriginal)
//        self.tabBar.items![4].image = UIImage(named: "icon_nav_mypage_glitter_off")!.withRenderingMode(UIImage.RenderingMode.alwaysOriginal)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.setTabBarItem(index: 0, title: Level.n5.rawValue, image: UIImage(named: "icon_nav_main_off")!, selectedImage: UIImage(named: "icon_nav_main_on")!) //, offColor: UIColor.blue, onColor: UIColor.red
        self.setTabBarItem(index: 1, title: Level.n4.rawValue, image: UIImage(named: "icon_nav_keep_off")!, selectedImage: UIImage(named: "icon_nav_keep_on")!)
    }
     
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
    }
    
    func tabBarController(_ tabBarController: UITabBarController, didSelect viewController: UIViewController) {
//        let index = self.viewControllers!.firstIndex(of: viewController)!
//        self.tabAnimation(index: index)
    }
    
    private func moveTab(index: Int) {
        //self.popToSelf()
//        self.selectedIndex = index
    }
    
    @IBAction func onClose(_ sender: Any) {
        self.dismiss(animated: true)
    }
    
    //タブバー作成
    func createTabBar() {
        let angeBlack = UIColor(displayP3Red: 48/255, green: 48/255, blue: 48/255, alpha: 1)
        let angeBlack75 = UIColor(displayP3Red: 48/255, green: 48/255, blue: 48/255, alpha: 0.75)
        let paleGray = UIColor(displayP3Red: 250/255, green: 250/255, blue: 250/255, alpha: 1)
        
        if #available(iOS 15, *) {
            let tabBarAppearance = UITabBarAppearance()
            self.tabBar.backgroundColor = paleGray
            tabBarAppearance.stackedLayoutAppearance.selected.titleTextAttributes = [.foregroundColor: angeBlack,
                                                             .font: UIFont.boldSystemFont(ofSize: 22)]
tabBarAppearance.stackedLayoutAppearance.normal.titleTextAttributes = [.foregroundColor: angeBlack75]
            //tabBarAppearance.stackedItemPositioning = .centered
            self.tabBar.standardAppearance = tabBarAppearance
            self.tabBar.scrollEdgeAppearance = tabBarAppearance
        } else {
            UITabBarItem.appearance().setTitleTextAttributes([.foregroundColor: UIColor.yellow], for: .selected)
            UITabBarItem.appearance().setTitleTextAttributes([.foregroundColor: UIColor.brown], for: .normal)
            self.tabBar.barTintColor = UIColor.gray
        }
        // 背景の透過
        UITabBar.appearance().backgroundImage = UIImage()
        // 境界線の透過
        UITabBar.appearance().shadowImage = UIImage()
        
        let line = UIView.init(frame: CGRect.init(x: 0, y:0, width: DeviceUtil.screenWidth, height: 0.25))
        line.backgroundColor = paleGray
        self.tabBar.addSubview(line)
        
        
        
        
//        self.tabBar.items![0].image = UIImage(named: "icon_nav_main_off")!.withRenderingMode(UIImage.RenderingMode.alwaysOriginal)
//        self.tabBar.items![1].image = UIImage(named: "icon_nav_keep_off")!.withRenderingMode(UIImage.RenderingMode.alwaysOriginal)
//        self.tabBar.items![2].image = UIImage(named: "icon_nav_footprint_off")!.withRenderingMode(UIImage.RenderingMode.alwaysOriginal)
//        self.tabBar.items![3].image = UIImage(named: "icon_nav_message_off")!.withRenderingMode(UIImage.RenderingMode.alwaysOriginal)
//        self.tabBar.items![4].image = UIImage(named: "icon_nav_mypage_glitter_off")!.withRenderingMode(UIImage.RenderingMode.alwaysOriginal)
        //self.tabBar.borderWidth = 1
        //self.tabBar.barTintColor = .brown
        //self.tabBarController?.tabBar.borderColor = UIColor(displayP3Red: 48/255, green: 48/255, blue: 48/255, alpha: 0.08)
        
//        self.tabBar.borderColor = UIColor(displayP3Red: 48/255, green: 48/255, blue: 48/255, alpha: 0.08)
//        self.tabBar.shadowImage = nil
//        self.tabBar.itemPositioning = .centered
    }
    
    func setTabBarItem(index: Int, title: String, image: UIImage, selectedImage: UIImage) -> Void {
        let tabBarItem = self.tabBarController?.tabBar.items![index]
        tabBarItem!.title = title
        tabBarItem!.image = image.withRenderingMode(.alwaysOriginal)
        tabBarItem!.selectedImage = selectedImage.withRenderingMode(.alwaysOriginal)
    }
    

    func viewController(with name: String, backgroundColor: UIColor) -> UIViewController {
        let vc = UIViewController()
        vc.view.backgroundColor = backgroundColor
        vc.title = name
//        vc.view.addSubview(self.toggleTabbarButton)
        return vc
    }
    
    
    
    func renderView() {
        print("WomenTBC")
        self.createTabBar()
        let vc1 = VocabVC()
        vc1.title = "Vocabulary".uppercased()
        vc1.view.backgroundColor = .white
        
        let vc2 = ReadVC()
        vc2.title = "Reading".uppercased()
        vc2.view.backgroundColor = .gray
        
        self.viewControllers = [vc1, vc2]
        //[VocabVC(), ReadVC()]
        //let vc = ReadVC()
        //self.navigationController?.pushViewController(vc, animated: true)
        //self.moveTab(index: 1)
        //self.selectedIndex = 0
        // Set up the Tab Bar Controller to have two tabs
        //let tabBarController = UITabBarController()
        //self.viewControllers = [SearchVC, NicedVC]
        //self.selectedIndex = TabType.search.rawValue
//        self.moveTab(index: TabType.search.rawValue)
//        let vc = SearchResult()
//        vc.view.backgroundColor = .red
//        navigationController?.pushViewController(vc, animated: true)
    }
    
    
}
