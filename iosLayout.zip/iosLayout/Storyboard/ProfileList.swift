//
//  ProfileList.swift
//  iosLayout
//
//  Created by nguyen thi ngoc hau on 2022/01/27.
//

import UIKit

class ProfileList: UIViewController, UICollectionViewDataSource, UICollectionViewDelegate, UICollectionViewDelegateFlowLayout {
    @IBOutlet weak var collectionView: UICollectionView!
    private var data: [SearchMember] = []
    var cellWidth = 0.0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.setLayoutCollectionFlow()
        self.renderView()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        cellWidth = CGFloat((DeviceUtil.screenWidth - 16*2 - 23)/2) //UIScreen.main.bounds.width
        print("\(cellWidth)")
    }
    
    func renderView() {
        print("profileLs")
        self.renderData()
        self.collectionView.reloadData()
    }
    
    ///MARK CollectionView
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 1
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        return 24
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
        return 23
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, insetForSectionAt section: Int) -> UIEdgeInsets {
        return UIEdgeInsets(top: 24, left: 16, bottom: 24, right: 16)
    }

    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = self.collectionView.dequeueReusableCell(withReuseIdentifier: "ProfCell", for: indexPath) as! ProfCell
        let index = indexPath.row
        cell.config(data: self.data[index])
        return cell
    }

    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return self.data.count
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return CGSize(width: self.cellWidth, height: self.cellWidth + 57)
    }
    
    func setLayoutCollectionFlow() {
        self.collectionView.register(UINib(nibName: "ProfCell", bundle: nil), forCellWithReuseIdentifier: "ProfCell")
    }
    
    func renderData() {
        self.data.removeAll()
        for i in 0..<10 {
            self.data.append(SearchMember(
                membersId: "member\(i+1)",
                sex: i % 2 == 0 ? "male" : "female",
                pr: "はじめまして！よろしくお願いします♪",
                nickname: "Member\(i+1)",
                prefName: "神奈川県",
                subphotoCnt: 5,
                isNew: 0,
                age: 30,
                profilePhotoUrl: i % 3 == 0 ? "img1" : i % 3 == 1 ? "img2" : "img4",
                loginStatus: (i % 3) == 0 ? 0 : (i % 3 == 1) ? 1 : 2
            ))
        }
        print(self.data)
    }
}
