//
//  JapaneseData.swift
//  iosLayout
//
//  Created by nguyen thi ngoc hau on 2022/01/31.
//

import Foundation

struct KanjiStructue: Codable {
    var data: [KanjiData]!
    
    private enum CodingKeys: String, CodingKey {
        case data
    }
    init() {
        self.data = []
    }
}

struct KanjiData: Codable {
    var kanji: String
    var hanviet: String
    var nghia: String
    var on: String
    var kun: String
    var words: [KanjWordData]
    
    private enum CodingKeys: String, CodingKey {
        case kanji
        case hanviet
        case nghia
        case on
        case kun
        case words
    }
    init() {
        self.kanji = ""
        self.hanviet = ""
        self.nghia = ""
        self.on = ""
        self.kun = ""
        self.words = []
    }
}

struct KanjWordData: Codable {
    var kanji: String
    var hanviet: String
    var read: String
    var nghia: String
    
    private enum CodingKeys: String, CodingKey {
        case kanji
        case hanviet
        case read
        case nghia
    }
    init() {
        self.kanji = ""
        self.hanviet = ""
        self.read = ""
        self.nghia = ""
    }
}
