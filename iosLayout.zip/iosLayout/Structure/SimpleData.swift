//
//  SimpleData.swift
//  iosLayout
//
//  Created by nguyen thi ngoc hau on 2022/01/26.
//

struct SearchMember {
    let membersId: String?
    let sex: String?
    let pr: String?
    let nickname: String?
    let prefName: String?
    let subphotoCnt: Int
    let isNew: Int?
    let age: Int?
    let profilePhotoUrl: String?
    let loginStatus: Int?
}

struct PhotoApiData: Codable {
    var members: [PhotoApi]!
    
    private enum CodingKeys: String, CodingKey {
        case members = "member"
    }
    init() {
        self.members = []
    }
}
struct PhotoApi: Codable {
    var profilePhotoUrl: String
    var subPhotosUrl: [String]!
    
    private enum CodingKeys: String, CodingKey {
        case profilePhotoUrl = "profile_photo_url"
        case subPhotosUrl = "sub_photos_url"
    }
    init() {
        self.profilePhotoUrl = "silhouette_man.png"
        self.subPhotosUrl = []
    }
}
