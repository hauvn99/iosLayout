//
//  DeviceUtil.swift
//  iosLayout
//
//  Created by nguyen thi ngoc hau on 2022/01/27.
//

import UIKit

class DeviceUtil{
    private static let width4inch : CGFloat = 320
            static let width4_7inch : CGFloat = 375
            static let width5_5inch : CGFloat = 414
    private static let height3_5inch : CGFloat = 480
    private static let height4inch : CGFloat = 568
    private static let height4_7inch: CGFloat = 667
    private static let height5_5inch: CGFloat = 736
    private static let height5_8inch: CGFloat = 812
    private static var deviceTypeValue: String!
    
    private static var osVersion : Int {
        return Int(UIDevice.current.systemVersion.components(separatedBy: ".")[0])!
    }
    
    //OK
    static var isIOS8 : Bool {
        return DeviceUtil.osVersion == 8
    }
    
    static var isIOS9 : Bool {
        return DeviceUtil.osVersion == 9
    }

    static var isIOS10AndLater : Bool {
        return DeviceUtil.osVersion >= 10
    }
    
    static var isIOS11AndLater: Bool {
        return DeviceUtil.osVersion >= 11
    }

    static var screenWidth : CGFloat {
        return UIScreen.main.bounds.size.width
    }
    
    static var screenHeight : CGFloat {
        return UIScreen.main.bounds.size.height
    }
    
    static var baseWidth : CGFloat {
        return width4inch
    }

    static var baseHeight : CGFloat {
        return height4inch
    }
    
    static var screenSize: CGSize {
        return CGSize(width: DeviceUtil.screenWidth, height: DeviceUtil.screenHeight)
    }

    static var is3_5inch : Bool{
        return DeviceUtil.screenHeight == height3_5inch
    }
    
    static var is4inch : Bool{
        return !DeviceUtil.is3_5inch && DeviceUtil.screenWidth == width4inch
    }
    
    static var lessThan4inch : Bool {
        return DeviceUtil.is3_5inch || DeviceUtil.is4inch
    }

    static var is4_7inch : Bool{
        return DeviceUtil.screenHeight == height4_7inch
    }

    static var is5_5inch : Bool{
        return DeviceUtil.screenHeight == height5_5inch
    }
    
    static var is5_8inch: Bool {
        return DeviceUtil.screenHeight == DeviceUtil.height5_8inch
    }
    
    static var hasSafeArea: Bool { return DeviceUtil.is5_8inch }

    //4inchとの比率
    static var basicRatio : CGFloat{
        return DeviceUtil.screenWidth / width4inch
    }
    //4.7inchとの比率。
    static var basicRatio_4_7 : CGFloat {
        return DeviceUtil.screenWidth / width4_7inch
    }
    
    static var statusBarHeight : CGFloat{
        return DeviceUtil.is5_8inch ? 44 : 20
    }
    
    static var naviBarHeight : CGFloat{
        return 44
    }
    
    static var naviHeight : CGFloat{
        return DeviceUtil.statusBarHeight + DeviceUtil.naviBarHeight
    }
    
    static var tabBarHeight : CGFloat{
        return DeviceUtil.is5_8inch ? 49
        :      DeviceUtil.is4_7inch ? 53
        :      DeviceUtil.is5_8inch ? 53
        :      DeviceUtil.is5_5inch ? 57
        :                             49
     }
    
    static var bottomSafeArea: CGFloat {
        return DeviceUtil.is5_8inch ? 34 : 0
    }
    
    static func rect(x: CGFloat, y: CGFloat, width: CGFloat, height: CGFloat) -> CGRect! {
        //デバイス毎に拡大
        return CGRect.init(x: x * DeviceUtil.basicRatio, y: y * DeviceUtil.basicRatio, width: width * DeviceUtil.basicRatio, height: height * DeviceUtil.basicRatio)
    }
    
    static func rect(frame: CGRect) -> CGRect! {
        //デバイス毎に拡大
        return CGRect(
            x: frame.origin.x,
            y: frame.origin.y,
            width: frame.width * DeviceUtil.basicRatio,
            height: frame.height * DeviceUtil.basicRatio)
        //return frame * DeviceUtil.basicRatio
    }
    
    static var deviceType: String {
        if DeviceUtil.deviceTypeValue == nil {
            var size = 0
            sysctlbyname("hw.machine", nil, &size, nil, 0)
            var machine = [CChar](repeating: 0, count: size)
            sysctlbyname("hw.machine", &machine, &size, nil, 0)
            let code = String(cString: machine)
            DeviceUtil.deviceTypeValue = code
        }
        return DeviceUtil.deviceTypeValue
    }
}
