//
//  LocalizeManager.swift
//  iosLayout
//
//  Created by nguyen thi ngoc hau on 2022/01/26.
//

import UIKit

func ls(_ key: String) -> String {
    return LocalizeManager.shared.localize(key: key)
}

func ls(_ key: String, args: Any...) -> String {
    return LocalizeManager.shared.exchangeArg(str: LocalizeManager.shared.localize(key: key), args: args)
}

class LocalizeManager {
    static let shared = LocalizeManager()
    private init() {}
    
    func localize(key: String) -> String {
        return NSLocalizedString(key, comment: "")
    }
    
    func exchangeArg(str: String, args: [Any]) -> String {
        var exchangeStr = str
        for (i, arg) in args.enumerated() {
            let stringValue = "\(arg)"
            exchangeStr = exchangeStr.regReplace(pattern: "%\(i + 1)\\$[dsf]", with: stringValue)
        }
        return exchangeStr
    }
}
